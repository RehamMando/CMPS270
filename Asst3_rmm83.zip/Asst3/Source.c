#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdlib.h>

int counter = 0;
int array[10];


void* count1s(void* temp) {
	int index = *(int*)temp;

	for (int i = 0; i < 5; i++) {
		if (array[index + i] == 1) {
			counter++;
		}
	}
	printf("\nlocal number of ones: %d", counter);
	free(temp);
}

int main(int argc) {

	printf("The array: {");
	for (int i = 0; i < 10; i++) {
		array[i] = rand() % 5;
		printf("%d ", array[i]);
	}
	printf("}\n");

	pthread_t thread[2];//number of threads
	int i;
	for (i = 0; i < 2; i++) {
		int* a = malloc(sizeof(int));
		*a = i * 5;
		pthread_create(&thread[i], NULL, &count1s, a);

	}
	clock_t start = clock();
	for (i = 0; i < 2; i++) {
		pthread_join(thread[i], NULL);

	}
	clock_t end = clock();
	double time = ((double)end - start) / CLOCKS_PER_SEC;
	printf("\nTime taken by the thread : %f", time);

	return 0;
}



/*number of threads = 1:
* array Size = 100, average time = 0.000048
* array Size = 10000, average time = 0.000108
* array Size = 100,000, average time = 0.000567909
* array Size = 1,000,000, average time = 0.004906
* array Size = 10,000,000, average time =0.0482362
* array Size = 100,000,000, average time = 0.004871189
* array Size = 1,000,000,000, average time = 0.000101
*/

/*number of threads = 2:
* array Size = 100, average time = 0.000089727
* array Size = 10000, average time = 0.0001609
* array Size = 100,000, average time = 0.00065
* array Size = 1,000,000, average time =0.005162
* array Size = 10,000,000, average time =0.0494426
* array Size = 100,000,000, average time = 0.5079775
* array Size = 1,000,000,000, average time = 0.000047
*/

/*number of threads = 4:
* array Size = 100, average time = 0.000101
* array Size = 10000, average time = 0.000163
* array Size = 100,000, average time = 0.000858
* array Size = 1,000,000, average time = 0.005362
* array Size = 10,000,000, average time = 0.05127
* array Size = 100,000,000, average time = 0.503999
* array Size = 1,000,000,000, average time = 0.000056
*/

/*number of threads = 8:
* array Size = 100, average time = 0.000219
* array Size = 10000, average time = 0.00024
* array Size = 100,000, average time = 0.000803
* array Size = 1,000,000, average time = 0.00554
* array Size = 10,000,000, average time = 0.054999
* array Size = 100,000,000, average time = 0.483096
* array Size = 1,000,000,000, average time = 0.000068
*/

/*number of threads = 16:
* array Size = 100, average time = 0.000747
* array Size = 10000, average time = 0.00071
* array Size = 100,000, average time = 0.000924
* array Size = 1,000,000, average time = 0.005868
* array Size = 10,000,000, average time = 0.047751
* array Size = 100,000,000, average time = 0.494812
* array Size = 1,000,000,000, average time = 0.000099
*/

/*number of threads = 32:
* array Size = 100, average time = 0.001078
* array Size = 10000, average time = 0.000254
* array Size = 100,000, average time = 0.001113
* array Size = 1,000,000, average time = 0.001772
* array Size = 10,000,000, average time = 0.005602
* array Size = 100,000,000, average time = 0.049685
* array Size = 1,000,000,000, average time = 0.000057
*/

/*number of threads = 64:
* array Size = 100, average time = 0.00136
* array Size = 10000, average time = 0.002411
* array Size = 100,000, average time = 0.002531
* array Size = 1,000,000, average time = 0.002122
* array Size = 10,000,000, average time = 0.018713
* array Size = 100,000,000, average time = 0.17388
* array Size = 1,000,000,000, average time = 0.000054
*/


